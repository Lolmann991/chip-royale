self.assetsManifest = {
  "version": "fjcT0NWL",
  "assets": [
    {
      "hash": "sha256-xs6VM061eya9IiP1ZxqVYYxD2C49MAPuRpgODlynobs=",
      "url": "_framework/ChipRoyale.Client.imd1an77rn.wasm"
    },
    {
      "hash": "sha256-7gEU/yjlKqLsu4Jq7XwFSYHX1MbskC6xcR3Mjg0FG2I=",
      "url": "_framework/ChipRoyale.Engine.28jv3y2jep.wasm"
    },
    {
      "hash": "sha256-K/wZPDjzX0EhpO1E+FWQxewhlRQJwHpXFb9+Fne4fDI=",
      "url": "_framework/ChipRoyale.Shared.z6v5722wva.wasm"
    },
    {
      "hash": "sha256-OsqX4+2uG2so+y+gf+tbI1iH/d8eauu5qSXcqHCZ0Rg=",
      "url": "_framework/Microsoft.AspNetCore.Components.2ew9ucjs7j.wasm"
    },
    {
      "hash": "sha256-GhUig6S36cjvBDY9bO/U6Oi8/9t8vmBSohCsMlbi6dc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.i91y08he5x.wasm"
    },
    {
      "hash": "sha256-fxF6/vO4ppuVLSKj/SURUmsGIvlqzGAdYm40oSsebgc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.9mmk3jv991.wasm"
    },
    {
      "hash": "sha256-1El3TYRttmSaKF+8waManURJgej38Lf9NdfH9HhOC4c=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.sc29i8ptiu.wasm"
    },
    {
      "hash": "sha256-Gvh3p8vjyX31HLeBNdpCKDIQzoEk+G+IWY9tMnJGFAM=",
      "url": "_framework/Microsoft.Extensions.Configuration.6o88ur47a6.wasm"
    },
    {
      "hash": "sha256-11QE0LYI+MQadr3hNsHuJTt4DWN1HXIeNS+VJCIJvjI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.vuo0vmw5q3.wasm"
    },
    {
      "hash": "sha256-CphRmDddas5BGASZtDje8kl72kzPuNOnNAj6O0+9/og=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.2673pa34ah.wasm"
    },
    {
      "hash": "sha256-NqsbAgakTV6Bd4kfI2/CvpVuoIM8yQll4Jd1Bgswf0o=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.iq9apzucpw.wasm"
    },
    {
      "hash": "sha256-e9+2ZBTYZqXt/eEzdBRd0RpMIdpfGLdG1em84dKzkV4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.pf1hzjp9pk.wasm"
    },
    {
      "hash": "sha256-7lMs6goSTk+NPfJXXoFb3jDgaJ/cS7xX3kZgf8RWdY0=",
      "url": "_framework/Microsoft.Extensions.Logging.6rc2jziest.wasm"
    },
    {
      "hash": "sha256-JVWX8JVU7o2Jzd9X6wQQKOGpQnDqPTmEj0+UN87Lh2I=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.z6a9zzyy84.wasm"
    },
    {
      "hash": "sha256-GXhpUwkRX0canpd7BRAiTE5qT+NWHnBkT2V4772spP8=",
      "url": "_framework/Microsoft.Extensions.Options.513zu0q8ar.wasm"
    },
    {
      "hash": "sha256-T0yMsxSVZKORth/PwZ3UZQJn1J2GpGuqRmYRkiBa2Ac=",
      "url": "_framework/Microsoft.Extensions.Primitives.xgxhoyl7m0.wasm"
    },
    {
      "hash": "sha256-Zx49Mo0sNavrF4LZmJlpCDbzcidTebPPXZDBHOjMO6s=",
      "url": "_framework/Microsoft.Extensions.Validation.pstbq37fdx.wasm"
    },
    {
      "hash": "sha256-TrC5o3+ev12lSNygM/Tp1ZUGAX2FXfRUXyt/lv4zNHI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.igy9hupfat.wasm"
    },
    {
      "hash": "sha256-O5p4JHVuKqhXSXYUaHAq8HesRRwKXFBWx7QziaEEia0=",
      "url": "_framework/Microsoft.JSInterop.z6kw0vh2f7.wasm"
    },
    {
      "hash": "sha256-8TKft+1nZ77OkXKSlCkeIr3LODgjo5/Zao7lnIEgPHg=",
      "url": "_framework/System.Collections.Concurrent.nq54jpizbw.wasm"
    },
    {
      "hash": "sha256-SqgT885KAxyl9vOKJPWDCE0v2cokE56/uWxysa0rTdA=",
      "url": "_framework/System.Collections.Immutable.25kb1rn79d.wasm"
    },
    {
      "hash": "sha256-f9ReoROnCmvmL7YkiLh4SI5jzphKTTQmCnsaSG/n11I=",
      "url": "_framework/System.Collections.NonGeneric.hsc3s7ndvh.wasm"
    },
    {
      "hash": "sha256-JQrNukJHE2mFJcIMl86Fg+JFDZTC6edk31oBGlpx0Sc=",
      "url": "_framework/System.Collections.Specialized.f7h3kag6r1.wasm"
    },
    {
      "hash": "sha256-K1CBo0nTpaawDp/IfnGIwYHfvMxPDgl3f1HuDUO/A9s=",
      "url": "_framework/System.Collections.prvk24ouds.wasm"
    },
    {
      "hash": "sha256-XnvKOuUMpDhKeadxeXKOeoupJdHJTy1XdgBQaRg93sI=",
      "url": "_framework/System.ComponentModel.Annotations.m2cx8eg785.wasm"
    },
    {
      "hash": "sha256-cnSfTB1I2HT7QDfgldbcCrG4aiF2uK7YFI20B4X/yq8=",
      "url": "_framework/System.ComponentModel.Primitives.adn17q9ns3.wasm"
    },
    {
      "hash": "sha256-IWVIdKQtO8nQsdwZQAPu3viqACU94h69lnWJ2YGiSJs=",
      "url": "_framework/System.ComponentModel.TypeConverter.jzyfwf4l9q.wasm"
    },
    {
      "hash": "sha256-SnOTYg3IeNG8IVMVAwvSaF3cEv3k4WQ48KcL41wziy0=",
      "url": "_framework/System.ComponentModel.ytwawerg14.wasm"
    },
    {
      "hash": "sha256-9YJOUzbTvm+r/x8dfh2ShI2A52hYZr/yIQoSF0A/moM=",
      "url": "_framework/System.Console.fjt6aqrc6s.wasm"
    },
    {
      "hash": "sha256-ddBMX9MT4SpF8jRMnvo0RlMIdWlNuZu2oV+aupRosq0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.9nfpt2j04z.wasm"
    },
    {
      "hash": "sha256-rks9bzzEZcDnCFUQSH7It96zMLr50b8rgM/gMgStZNw=",
      "url": "_framework/System.IO.Pipelines.uxxioc395v.wasm"
    },
    {
      "hash": "sha256-aOmkSd1YuwwvSF4VoSgyGEbBumujCXQhXq7IDmfKJmo=",
      "url": "_framework/System.Linq.Expressions.sbgbyw6ao8.wasm"
    },
    {
      "hash": "sha256-bkjR5x7efLv7LJ0zCVQdc7g8kUGM8VHc8acedteCTag=",
      "url": "_framework/System.Linq.e51vk3q63u.wasm"
    },
    {
      "hash": "sha256-69M81JAOfML7lgL1+PwPD+tFJUeXFGv+V6tJn5wi4VI=",
      "url": "_framework/System.Memory.h9gjvxz2sx.wasm"
    },
    {
      "hash": "sha256-fDucItGimiG51tKnJWs5Fv1OXQvXxuKnInz9qnaGlq8=",
      "url": "_framework/System.Net.Http.4omfo7txod.wasm"
    },
    {
      "hash": "sha256-QjQkIbHS3abNs6yIT6X5ybDVZoEY5eRehBkAg5G4OZw=",
      "url": "_framework/System.Net.Http.Json.2v2pl7suc6.wasm"
    },
    {
      "hash": "sha256-naJ2HuWzvyYLAChSN35TF4bDYAb0nKLPZGItaYWqWk0=",
      "url": "_framework/System.Net.Primitives.tst7gws7xy.wasm"
    },
    {
      "hash": "sha256-hCmoCN9tt9AiLSTideLABngXJJjT1D8fZ3zXFX2QvLo=",
      "url": "_framework/System.ObjectModel.w18jimhwzq.wasm"
    },
    {
      "hash": "sha256-ApHXoFKFhKfqtwDAxxnwlRivi3WM3gZ59F/XSv7cImo=",
      "url": "_framework/System.Private.CoreLib.6624jazsi1.wasm"
    },
    {
      "hash": "sha256-NAvtoTbIgj4ldFUoJdOIByxl40YXrIMqey0mW5dE4BM=",
      "url": "_framework/System.Private.Uri.kcbv0g0i0f.wasm"
    },
    {
      "hash": "sha256-4S76Z6V245aKZNHQHXSxPUl98xj3MH4uXwwVR4TzF9I=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.vs9238bmr6.wasm"
    },
    {
      "hash": "sha256-dcINqnHj/vx+/dXjP0ZmXz17oPEfT4xwqdum5uQciH0=",
      "url": "_framework/System.Runtime.InteropServices.tms6ssaz0a.wasm"
    },
    {
      "hash": "sha256-CbjWoPFX5RgFQLUaLTnWA8A2oWTylUtRW/LIu5xALS8=",
      "url": "_framework/System.Runtime.Serialization.Primitives.pol9aq3nyl.wasm"
    },
    {
      "hash": "sha256-igEYWr6jghtX6o2jiqM1SBcvX6OzOsD7ndK6b82lOpk=",
      "url": "_framework/System.Runtime.yyq0ltvr93.wasm"
    },
    {
      "hash": "sha256-dxzQIWl+zu+UCxpmldJkIYUW2BPFvRps7q6dkQVaF5Q=",
      "url": "_framework/System.Security.Cryptography.1m3x3gb6eu.wasm"
    },
    {
      "hash": "sha256-9uxkZc7c50dVPzCMbqV2EdpfE0lt+wAi7VNkKr5wHNw=",
      "url": "_framework/System.Text.Encodings.Web.29zaodjq3a.wasm"
    },
    {
      "hash": "sha256-55m22RsWXdV5vwubqVVnQa2RB5xlr4J3fB1in/tdw7M=",
      "url": "_framework/System.Text.Json.n0l6mp5zm8.wasm"
    },
    {
      "hash": "sha256-RdkQZBQ7i90pn1hN5Y+8lF6hY7+tzBXp2+i5wY1oxms=",
      "url": "_framework/System.Text.RegularExpressions.9nwcdrvxaa.wasm"
    },
    {
      "hash": "sha256-o70nsSnUpZ9NEiP23saiIj6RzDXZSwxfZSy+L+GwFZo=",
      "url": "_framework/System.Threading.jcah7q64kf.wasm"
    },
    {
      "hash": "sha256-mZ7y24m4d4nPhekDCaX/s4ndZUg4tuEzoGPjRPw1Xsw=",
      "url": "_framework/System.bzv2fdl90t.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-/n085PseQMKHkbJihAkayfK6VSn25Txr7lNzoPo/DIk=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-X9HNNO0PWod7guUohAjrSJMj6QxYLCm+SljNYaT8Nho=",
      "url": "_framework/dotnet.native.3bptkeu1pi.wasm"
    },
    {
      "hash": "sha256-YvNi2Q+yHnXi8iT7ROza0OEWWv2tCpuTI2Ggaeura3U=",
      "url": "_framework/dotnet.native.6ilbvndvcf.js"
    },
    {
      "hash": "sha256-6SBqDbLLy460Bxd7wMZoiO97hZfLTuF+HRhWT3elS7U=",
      "url": "_framework/dotnet.runtime.v2rwe8u38b.js"
    },
    {
      "hash": "sha256-lkRS05EAoUWtJ8hUyJ39SoeJimvEU3NYV4Cb1jFsEJQ=",
      "url": "_framework/en/ChipRoyale.Client.resources.m5q0bf3u32.wasm"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-nGNvbrtX7XOZ0vmIXfT3yFxhfRXBRiZLZluiOK70oXQ=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-umlwwjkBRGBhdnqVpH5pu6A3dpw6PTcGSDu/KK+kZPo=",
      "url": "css/game.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-Ncg4gwaGZMa/NiGo+rmHJoCkZo7bcMyCkArvjf+OHp4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-kMuS3r61MLQXm3tbS2e9bd5giKe2nJnGtM/S4SUTcyw=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-iwBDV1m3fwF2IB/xvX6uKhNUvUBStPrjWoxWkdm/GOg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-yP+sXYkqKuZUZWYROm/XaHfdDcSJL7id3APN/HicfXk=",
      "url": "js/table.js"
    },
    {
      "hash": "sha256-lPjfwbf2VAwlpuYI0FkIEONwg+XW6FDdQlOirgr3YKg=",
      "url": "manifest.webmanifest"
    }
  ]
};
